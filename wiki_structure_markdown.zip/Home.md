# ⚔️ West Marches – Free City of Greyhawk

Bem-vind@ à wiki da nossa campanha **West Marches**, com base na lendária **Free City of Greyhawk**.

Este espaço serve para organizar o mundo, os personagens, as sessões e as descobertas feitas por cada grupo de aventureiros.

Tudo o que encontrares aqui pode mudar com o tempo — a história é viva, e és parte dela.

---

## 🌆 Locais Principais

- [[Free City of Greyhawk]]
- [[The Company]]
- [[Ruin Sites Index]]

---

## 🏙️ Bairros da Cidade

- [[High Quarter]]
- [[Garden Quarter]]
- [[University Quarter]]
- [[River Quarter]]
- [[Thieves’ Quarter]]
- [[Artisans’ Quarter]]
- [[Foreign Quarter]]
- [[City Market]]
- [[Slum Quarter]]

---

## 🛐 Locais e Estruturas

- [[Templo de Oghma]]
- [[Grande Biblioteca]]
- [[Universidade Arcana]]
- [[Estalagem da Companhia]]
- [[Rua do Dragão Enferrujado]]

---

## 👥 NPCs em Destaque

- [[Lord Aleister Devraine]]
- [[Sister Blathine]]
- [[Mistress Lyral Quil]]
- [[Tomtha Beaknose]]
- [[Iquander]]
- [[Jandel the Lintwatcher]]
- [[Talandra Valxar]]

---

## 📜 Sessões e Registos

- [[Sessão 1 – A Chegada a Greyhawk]]
- [[Sessão 2 – O Ídolo Chama]]
- [[Sessão 3 – A Cúpula Submersa]]
- [[Registos por Jogador]]
- [[Resumo de Campanha]]

---

## ⚙️ Regras e Utilitários

- [[House Rules]]
- [[Downtime Guide]]
- [[Loot & Magic Ledger]]
- [[Calendário & Eventos Atuais]]
